/**
 * The meat of the game.
 */
package cruftyKrab.game;