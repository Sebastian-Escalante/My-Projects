package cruftyKrab.game.events;

/**
 * Signals that a round is over.
 *
 * @author Ches Burks
 *
 */
public class RoundOver extends CancellableEvent {}
