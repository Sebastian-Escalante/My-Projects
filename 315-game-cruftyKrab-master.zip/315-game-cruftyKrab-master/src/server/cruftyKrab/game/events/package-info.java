/**
 * Events for the server and games, all in one place.
 */
package cruftyKrab.game.events;