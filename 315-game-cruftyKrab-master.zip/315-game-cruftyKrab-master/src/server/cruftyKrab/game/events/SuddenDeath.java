package cruftyKrab.game.events;

/**
 * The game should start spawning until everyone is dead.
 *
 * @author Ches Burks
 *
 */
public class SuddenDeath extends CancellableEvent {}
