package cruftyKrab.game.events;

/**
 * The game should move enemies to the top left.
 *
 * @author Ches Burks
 *
 */
public class Freeze extends CancellableEvent {}
