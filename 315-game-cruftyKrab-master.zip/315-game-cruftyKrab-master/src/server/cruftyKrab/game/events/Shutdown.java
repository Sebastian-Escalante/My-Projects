package cruftyKrab.game.events;

/**
 * The game is shutting down.
 *
 * @author Ches Burks
 *
 */
public class Shutdown extends CancellableEvent {}
