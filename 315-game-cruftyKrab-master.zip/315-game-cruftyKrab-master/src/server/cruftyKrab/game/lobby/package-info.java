/**
 * Code related to the Lobby package (as in Ikala's
 * {@link com.ikalagaming.packages.Package Package}).
 */
package cruftyKrab.game.lobby;