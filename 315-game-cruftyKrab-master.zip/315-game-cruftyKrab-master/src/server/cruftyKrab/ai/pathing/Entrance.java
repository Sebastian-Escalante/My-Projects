package cruftyKrab.ai.pathing;

/**
 * A maximal obstacle-free segment along the shared border of two adjacent
 * clusters.
 *
 * @author Ches Burks
 *
 */
public class Entrance {

}
