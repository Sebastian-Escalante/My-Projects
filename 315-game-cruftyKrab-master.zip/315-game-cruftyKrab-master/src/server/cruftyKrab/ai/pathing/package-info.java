/**
 * Code related to finding optimized paths around the map for AI movement.
 */
package cruftyKrab.ai.pathing;