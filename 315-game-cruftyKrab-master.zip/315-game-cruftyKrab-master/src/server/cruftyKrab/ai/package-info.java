/**
 * Handles calculations for computer controlled mascots.
 */
package cruftyKrab.ai;