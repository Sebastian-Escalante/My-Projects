/**
 * Classes that represent messages to be converted to/from JSON and transmitted
 * between client and server.
 */
package cruftyKrab.network.messages;