/**
 * Messages sent to the server from the client.
 */
package cruftyKrab.network.messages.in;