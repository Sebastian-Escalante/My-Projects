/**
 * Events concerning network connections.
 */
package cruftyKrab.network.events;