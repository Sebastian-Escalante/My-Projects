/**
 * Code for handling networking with clients.
 */
package cruftyKrab.network;