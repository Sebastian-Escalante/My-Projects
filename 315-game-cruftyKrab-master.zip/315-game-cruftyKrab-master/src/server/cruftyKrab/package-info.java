/**
 * Code for the AggieDefender game.
 */
package cruftyKrab;