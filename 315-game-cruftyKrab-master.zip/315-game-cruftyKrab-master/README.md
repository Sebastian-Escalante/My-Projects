# 315-game-cruftyKrab

This is the repo for our Multiplayer Game Project

Team Memebers

David(Ches) Burks

Jacque Laws

Sebastian Escalante

Development Log: https://docs.google.com/document/d/1BZRHK_y6mgtLdKubeRnfvliWjLiFEnoxO0Yd2iQw8MQ/edit

#Deliverable 1

Game Design Document: https://docs.google.com/document/d/1-l8g_amhL9E6MAoRKW_UQPDxdKn5f3P0VKkW1cUVmcs/edit

Idea Mache: https://ideamache.ecologylab.net/e/qXIv7XNRia/

#Deliverable 2

Formative User Study:https://docs.google.com/document/d/1nRKIwmxNLpVQADd_MfGBPHwwYfTdLul94TTwKAmTyjY/edit

Re-designed Game Design: https://docs.google.com/document/d/1KngwiMCb6W0nS_nvFevSb27rTv1eCuTfR2ivzcpwTKE/edit

Idea Mache: https://ideamache.ecologylab.net/e/454QLA9oyh/

#Deliverable 3

Functional Specification: https://docs.google.com/document/d/1kLujS8e1jPVvWYEQc8tWfbB8EzhQx5lUfW0moEyBsT0/edit#

Idea Mache: https://ideamache.ecologylab.net/e/CDY8h2YF4l/

#Deliverable 4

Functional Prototype: https://docs.google.com/document/d/1SZgkuFtnmHkHY8VIgxhnEf79ARZ-YrjxqmFElKr4yUo/edit

Idea Mache: https://ideamache.ecologylab.net/e/ASLQV7anE9/

got to the src folder. type node app.js to get the client running.

Got to http://compute.cse.tamu.edu:13000/ to see the client.

To compile the server, run `ant` in the root folder. If you want to clean up compiled code/distributables, type `ant clean`.

To run the server, navigate into the dist folder and run `java -jar server.jar`. 
You can interact using the console, and to shutdown cleanly, type `shutdown`. 

#Deliverable 5

Formtive User Study II: https://docs.google.com/document/d/15WLf7_xtiN99V0V-0Ued8kNb0OG9fpPFMQxa5LHguqE/edit

Revised Functioanl Specification: https://docs.google.com/document/d/11JvwO7xyENJzWYGlWrgyYNp8lH1Uhgvyt039jb_JiG8/edit

Idea Mache: https://ideamache.ecologylab.net/e/5rzPLiBDF3/

#Deliverable 6

Functional Prototype II: https://docs.google.com/document/d/1YWRNaIB2MMZW56kCtN67gjhnw-y3sBeJyOJa2kNl7vI/edit?usp=sharing

Idea Mache: https://ideamache.ecologylab.net/e/TPfqXm9DRE/

to compile: type 'ant'

to run you will need two terminal windows open.
window 1- To run the server, navigate into the dist folder and run `java -jar server.jar`. 
You can interact using the console, and to shutdown cleanly, type `shutdown`. 
window 2- navigate to src folder and run `node app.js`.

to view game go to `compute.cs.tamu.edu:13000`.
